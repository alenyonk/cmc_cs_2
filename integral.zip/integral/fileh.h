#ifndef MY_H
#define MI_H

#include <stdio.h>

float root(float f(float), float g(float), float a, float b, float eps1);
float integral(float f(float), float a, float b, float eps2, int n);
float abss(float x);

#endif